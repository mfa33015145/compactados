# Travel Carousel Design

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/JjVgROO](https://codepen.io/icomgroup/pen/JjVgROO).


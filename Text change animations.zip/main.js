(function ($) {
    $(function () {
  
      
  
    });
  })(jQuery);
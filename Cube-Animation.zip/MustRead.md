## To Run the Project

### Step 1: npm install

### Step 2: npm run start

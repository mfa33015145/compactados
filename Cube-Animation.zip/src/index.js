// Importing GSAP
import { TimelineMax, Power2, Power3, Elastic } from 'gsap';

// Classic
var i;

// Other global vars :')
var boxToCenter, boxesToReset, dotColor;

// Setup vars for boxes
var reaBox = document.querySelector(".React");
var vanBox = document.querySelector(".Vanilla");
var angBox = document.querySelector(".Angular");
var vueBox = document.querySelector(".Vue");

// Center React
function centerReact() {
	if (boxToCenter !== reaBox) {
		boxToCenter = reaBox;
		boxesToReset = [vanBox, angBox, vueBox];
		dotColor =
			"rgb(" +
			getComputedStyle(document.documentElement).getPropertyValue("--blue") +
			")";
		animateBoxes(boxToCenter, boxesToReset, dotColor);
	}
}

// Center Vanilla
function centerVanilla() {
	if (boxToCenter !== vanBox) {
		boxToCenter = vanBox;
		boxesToReset = [reaBox, angBox, vueBox];
		dotColor =
			"rgb(" +
			getComputedStyle(document.documentElement).getPropertyValue("--orange") +
			")";
		animateBoxes(boxToCenter, boxesToReset, dotColor);
	}
}

// Center Vue
function centerVue() {
	if (boxToCenter !== vueBox) {
		boxToCenter = vueBox;
		boxesToReset = [vanBox, angBox, reaBox];
		dotColor =
			"rgb(" +
			getComputedStyle(document.documentElement).getPropertyValue("--green") +
			")";
		animateBoxes(boxToCenter, boxesToReset, dotColor);
	}
}

// Center Angular
function centerAngular() {
	if (boxToCenter !== angBox) {
		boxToCenter = angBox;
		boxesToReset = [vanBox, reaBox, vueBox];
		dotColor =
			"rgb(" +
			getComputedStyle(document.documentElement).getPropertyValue("--red") +
			")";
		animateBoxes(boxToCenter, boxesToReset, dotColor);
	}
}

// Set animating function
function animateBoxes(boxToCenter, boxesToReset, dotColor) {
	var tl = new TimelineMax();
	tl.addLabel("start");

	// Animate box to center
	tl.to(boxToCenter, 0.2, { scale: 0.55 }, "start");
	tl.to(boxToCenter, 0.7, { left: "0", bottom: "0", ease: Power3.easeIn });
	tl.to(boxToCenter, 0.7, { scale: 0.8, ease: Elastic.easeOut });
	tl.to("html", 0.2, { "--dot-color": dotColor }, "-=.7");

	// Call function to reset other boxes
	resetBoxes(boxesToReset);
}

function resetBoxes(boxesToReset) {
	// Loop over all the boxes that it should reset, check which box it is, and animate accordingly
	for (i = 0; i < boxesToReset.length; i++) {
		if (boxesToReset[i].classList.contains("React")) {
			new TimelineMax().to(
				boxesToReset[i],
				0.6,
				{ scale: 0.5, left: "0", bottom: "150px", ease: Power2.easeOut }
			);
		} else if (boxesToReset[i].classList.contains("Vanilla")) {
			new TimelineMax().to(
				boxesToReset[i],
				0.6,
				{ scale: 0.5, left: "150px", bottom: "0", ease: Power2.easeOut },
				"start"
			);
		} else if (boxesToReset[i].classList.contains("Angular")) {
			new TimelineMax().to(
				boxesToReset[i],
				0.6,
				{ scale: 0.5, left: "0", bottom: "-150px", ease: Power2.easeOut },
				"start"
			);
		} else if (boxesToReset[i].classList.contains("Vue")) {
			new TimelineMax().to(
				boxesToReset[i],
				0.6,
				{ scale: 0.5, left: "-150px", bottom: "0", ease: Power2.easeOut },
				"start"
			);
		}
	}
}

// Setup eventlisteners
reaBox.addEventListener("click", function() {
	centerReact();
});
vanBox.addEventListener("click", function() {
	centerVanilla();
});
vueBox.addEventListener("click", function() {
	centerVue();
});
angBox.addEventListener("click", function() {
	centerAngular();
});
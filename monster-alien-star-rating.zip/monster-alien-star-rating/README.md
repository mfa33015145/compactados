# Monster Alien Star Rating

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/LYoNBgO](https://codepen.io/icomgroup/pen/LYoNBgO).


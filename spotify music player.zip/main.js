$(function(){
    var nav = document.querySelector("nav");
    $(nav).draggable();
})
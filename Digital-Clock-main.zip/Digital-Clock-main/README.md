# Digital-Clock 🤩 

https://github.com/anaslaghrissi/Digital-Clock/assets/108026572/9c1cdde3-47e1-4727-99ff-1cd1661094cd
